<?php
/**
* @title		JoomShaper registration module
* @website		http://www.joomshaper.com
* @Copyright 	(C) 2010 - 2012 joomshaper.com. All rights reserved.
* @license		GNU/GPL
**/

// no direct access
defined('_JEXEC') or die('Restricted access');
require(JModuleHelper::getLayoutPath('mod_register'));