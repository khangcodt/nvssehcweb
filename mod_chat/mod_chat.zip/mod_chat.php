<?php

// no direct access
defined('_JEXEC') or die;

require JModuleHelper::getLayoutPath('mod_chat', $params->get('layout', 'default'));
